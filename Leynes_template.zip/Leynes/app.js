const express = require('express');
const nics = require('./routes/NicoleRouter');
const bodyParser = require('body-parser');
const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true}));
app.get('/', nics);
app.use(express.static('public'));

app.listen(3000, () => {
    console.log('server running on http://localhost:3000');
});