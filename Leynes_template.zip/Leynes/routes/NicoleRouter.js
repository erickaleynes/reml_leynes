const express = require("express");
const router = express.Router();
const main = require("../controller/NicoleController");

router.get('/', main.main);


module.exports = router;