const express = require('express');
const router = express.Router();
const home = require('../controller/UserController.js');

router.get('/', home.index);
router.get('/about', home.about);
router.get('/blog', home.blog);
router.get('/contact', home.contact);
router.get('/pages', home.pages);

module.exports = router;